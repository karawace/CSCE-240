// Copyright 2024 wacenske CSCE 240 Summer

#include <hw3/inc/parse_demographics.h>

const std::string** ParseDemographics(const std::size_t rows,
                                      const std::size_t cols[],
                                      const std::string** values) {
  std::string **demographics  = new std::string*[rows];
  std::size_t index = 0;
  for (std::size_t i = 0; i < rows; ++i) {
    demographics[index] = new std::string(values[i][0]);
    ++index;
    for (std::size_t ii = 1; ii < cols[i]; ++i) {
      switch (values[i][ii].front()) {
        case 'E': {
          ++ii;  // move to number of ethnicities
          std::size_t n = std::stoi(values[i][ii]);
          if (n == 0) {
            demographics[index] = nullptr;
            ++index;
          } else if (n == 1) {
            demographics[index] = new std::string(values[i][ii]);
          } else {
          }
          break;
        }
        case 'B': {
          ++ii;  // move to month of DOB
          demographics[index] = new std::string[3];
          demographics[index] = new std::string(values[i][ii]);
          ++index;
          break;
        }
      }
    }
  }
  const std::string** const_demographics =
    const_cast<const std::string**>(demographics);
  return const_demographics;
}
